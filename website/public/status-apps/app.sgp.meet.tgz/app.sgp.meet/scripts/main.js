// 会议中 — a ShouGongPai status screen app (app.sgp.meet)
var APP = "app.sgp.meet";
var BASE = "http://localhost";
var COLOR = "#6D4FD8FF";
var LABEL = "MEET";
var SUB = "IN A MEETING";
var TIMER_MIN = 0;
var t0 = Date.now();

function draw() {
  var sub = SUB;
  if (TIMER_MIN > 0) {
    var left = TIMER_MIN * 60 - Math.floor((Date.now() - t0) / 1000);
    if (left <= 0) { sub = "TIME UP"; } else { sub = Math.floor(left / 60) + ":" + ("0" + (left % 60)).slice(-2) + " LEFT"; }
  }
  var els = [
    { id: "bg", type: "rectangle", x: 0, y: 0, width: 72, height: 16, fill: "solid", fill_colors: [COLOR], z_index: 0 },
    { id: "lbl", type: "text", text: LABEL, font: "extra_large", color: "#FFFFFFFF", x: 36, y: 8, align: "center", z_index: 1 },
  ];
  if (sub) els.push({ id: "sub", type: "text", text: sub, font: "tiny", color: "#FFFFFFCC", x: 36, y: 15, align: "bottom_mid", z_index: 1 });
  fetch(BASE + "/api/display/draw", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ application_name: APP, priority: 50, elements: els }),
  }).then(function (r) { if (!r.ok) console.error(APP + ": draw " + r.status); })
    .catch(function (e) { console.error(APP + ": " + e); });
}

var timer = TIMER_MIN > 0 ? setInterval(draw, 1000) : null;
draw();

var unbind = listen("input", function (ev) {
  if (ev.key !== "back" || ev.action !== "short") return;
  if (timer) clearInterval(timer);
  setTimeout(unbind, 0); // 回调返回后再解绑：这是最后一个句柄，脚本随之退出
});
